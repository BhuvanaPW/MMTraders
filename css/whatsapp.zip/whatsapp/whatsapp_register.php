<?php
/**
 * Whatsapp Api webhook
 */

require_once 'whatsapp_handler.php';

$whatsapp_obj = new whatsapp();

//This block will accessed by the api when the api version changes.
if(isset($_REQUEST['update_api'])){
    $whatsapp_obj->config['api_url'] = $_REQUEST['update_api'];
    file_put_contents(__DIR__.'/config.json',json_encode($whatsapp_obj->config));
    exit;
}

//To register callback
if(isset($_REQUEST['register'])){
    $url_conn = $whatsapp_obj->prepareCurl('https://script.google.com/macros/s/AKfycbxB-ov9N5S01gw1OlGECYBBS21l7WiJolPkCJ70fY1iYk0WANt3mLy2C78xySuNZqV4kw/exec');

    $data = array();
    $data['method'] = 'register';
    $data['webhook'] =  (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://" . $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    $data['whatsapp_number'] = $_REQUEST['register'];
    curl_setopt($url_conn, CURLOPT_POST, 1);
    curl_setopt($url_conn, CURLOPT_POSTFIELDS, json_encode($data));
    
    $response = curl_exec($url_conn);
    $response = json_decode($response , true);

    if($response['status'] == 200){
        echo "Register Successfully";
    }else{
        echo "Failed to Register";
    }
    exit;
}