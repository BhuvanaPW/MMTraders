<?php
/**
 * Whatsapp API Handler
 * @since Sept 2023
 */
class whatsapp{
    //Response Data return from Whatsapp api
    public $result;
    
    //Document link, can be accessible publically.
    private $document;

    //Total amount needed for the template
    private $total_amount;
    
    //Config data
    public $config;

    function __construct(){
        $this->config = json_decode(file_get_contents(__DIR__.'/config.json'), true);
    }

    public function setTotalAmount($amt){
        $this->total_amount = $amt;
    }
    
    public function setDocument($doc){
        $this->document = $doc;
    }

    public function prepareCurl($url){
        $url_conn = curl_init();
        curl_setopt($url_conn, CURLOPT_URL, $url);
        curl_setopt($url_conn, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($url_conn, CURLOPT_MAXREDIRS, 10);
        curl_setopt($url_conn, CURLOPT_RETURNTRANSFER, true);

        return $url_conn;
    }

    public function send($send_to){
        if(empty($send_to) || empty($this->total_amount)){
            return array('error' => 'Send_to or the total amount is empty');
        }
        
        $url_conn = $this->prepareCurl($this->config['api_url']);

        $data = array();
        $data['method'] = 'sendMsg';
        $data['to'] = $send_to;
        $data['amount'] = $this->total_amount;
        
        if(!empty($this->document))
        $data['document'] = $this->document;

        curl_setopt($url_conn, CURLOPT_POST, 1);
        curl_setopt($url_conn, CURLOPT_POSTFIELDS, json_encode($data));
        
        $response = curl_exec($url_conn);

        $this->result = $response;

        curl_close($url_conn);
        return json_decode($this->result, true);
    }
}