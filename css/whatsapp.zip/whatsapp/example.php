<?php

require 'whatsapp_handler.php';

$whatsapp_obj = new whatsapp();

$whatsapp_obj->setTotalAmount('525.00');
$whatsapp_obj->setDocument('https://focuspyro.com/pdf/525');
$res = $whatsapp_obj->send('8778936468');

echo "response : ";
print_r($res);